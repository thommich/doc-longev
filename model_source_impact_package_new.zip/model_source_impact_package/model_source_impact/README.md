# model-source-impact

A configuration-driven regression-testing framework for assessing ML model impact when feature sources are migrated from legacy tables to modernized tables.

The package is intentionally infrastructure-agnostic: Athena/Spark/SageMaker-specific extraction and model loading live in small adapter callables supplied by each project, while comparison, validation, scoring reconciliation, risk-group reconciliation and Gini comparison remain reusable.

## What it measures

For each model/reference-date experiment the runner:

1. Builds one fixed population.
2. Builds a baseline feature table from legacy sources.
3. Builds a candidate feature table from modernized sources.
4. Verifies one-to-one population alignment.
5. Reconciles every migrated feature.
6. Scores both tables with the same model/scoring callable.
7. Measures score equality after rounding, score tolerance in percentage points, score differences and rank correlations.
8. Recalculates risk groups and produces group distributions plus transition matrices.
9. On a matured historical period, computes baseline/candidate Gini and a paired bootstrap confidence interval for delta Gini.
10. Applies centrally configured PASS/INVESTIGATE thresholds.

## Installation

```bash
pip install -e .
```

For development:

```bash
pip install -e ".[dev]"
pytest -q
```

## Core architecture

Your project supplies three adapters:

```python
def population_builder(model, reference_date, include_target) -> pd.DataFrame:
    ...


def feature_table_builder(population, model, migrations, side, reference_date) -> pd.DataFrame:
    ...


def scorer(frame, model) -> np.ndarray:
    ...
```

The feature-table builder must return columns using the **canonical feature names expected by the model**, regardless of the physical source-column names.

This means table/column renaming logic belongs in the extraction adapter, not in the generic comparison engine.

## Model registry

```python
from model_source_impact import ModelConfig

MODELS = {
    "model_01": ModelConfig(
        name="model_01",
        id_cols=("customer_id",),
        target_col="target",
        feature_names=("f1", "f2", "f3"),
        risk_group_cutoffs=(0.1, 0.2, 0.4, 0.7),
        risk_group_labels=("G1", "G2", "G3", "G4", "G5"),
    )
}
```

## Migration registry

```python
from model_source_impact import FeatureSpec, SourceMigrationConfig

MIGRATIONS = {
    "transactions_v2": SourceMigrationConfig(
        name="transactions_v2",
        baseline_source="legacy.transactions",
        candidate_source="modern.transactions",
        features=(
            FeatureSpec("txn_count_3m", atol=0.0, rtol=0.0),
            FeatureSpec("txn_value_6m", atol=1e-8, rtol=1e-9),
        ),
    )
}
```

A migration may be reused by any number of models.

## Experiment manifest

```python
from model_source_impact import ExperimentConfig

EXPERIMENTS = [
    ExperimentConfig(
        model_name="model_01",
        reference_date="2026-07",
        migrations=("transactions_v2",),
        include_target=False,
        experiment_name="model_01_recent",
    ),
    ExperimentConfig(
        model_name="model_01",
        reference_date="2025-06",
        migrations=("transactions_v2",),
        include_target=True,
        experiment_name="model_01_matured",
    ),
]
```

## Running the suite

```python
from model_source_impact import ExperimentRunner

runner = ExperimentRunner(
    models=MODELS,
    migrations=MIGRATIONS,
    population_builder=population_builder,
    feature_table_builder=feature_table_builder,
    scorer=scorer,
    keep_row_level=True,
)

results, executive_summary = runner.run_suite(EXPERIMENTS)
```

`executive_summary` contains one row per experiment. Each `ExperimentResult` additionally exposes feature reconciliation, group distributions, transition matrices, bootstrap Gini results and optionally row-level deltas for investigation.

## Recommended repository layering at work

```text
impact-assessment/
├── pyproject.toml
├── src/
│   ├── model_source_impact/       # generic package (this package)
│   └── project_adapters/          # bank/project-specific code
│       ├── populations.py
│       ├── feature_tables.py
│       ├── model_loader.py
│       └── scorers.py
├── configs/
│   ├── models.py
│   ├── migrations.py
│   └── experiments.py
├── notebooks/
│   ├── 01_run_assessment.ipynb
│   └── 02_investigate_differences.ipynb
└── tests/
```

Keep credentials, account names, physical table details and model-artifact loading outside the generic package.

## Important interpretation detail: 1 p.p.

The default score comparison treats scores as probabilities in `[0, 1]`. Therefore `1 p.p.` means an absolute score difference of `0.01`. If one of your production models emits scores on another scale, normalize the score before comparison or adapt the metric deliberately.

## Codex-ready repository guidance

`AGENTS.md` contains project-wide engineering/invariant instructions suitable for an agent working in the repository. `CODEX_HANDOFF.md` contains a staged integration task for adapting the generic package to the real 9-model / 5-migration codebase after repository-specific production utilities are available.
