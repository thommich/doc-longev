# Agent instructions for model-source-impact

## Goal
Maintain a small, auditable Python framework for regression-testing feature-source migrations across production credit-risk models.

## Architectural boundaries
- `src/model_source_impact/` must remain infrastructure-agnostic.
- AWS/Athena/Spark/SageMaker, credentials, physical table joins, and model-artifact loading belong in project adapters outside the generic package.
- Model-specific behavior should be configuration or injected callables whenever practical.
- Never duplicate the full experiment flow per model.

## Invariants
1. Baseline and candidate must be evaluated on the same immutable population.
2. The only intended baseline/candidate difference is the configured migrated feature source(s).
3. Source columns must be normalized to canonical model feature names before generic comparison/scoring.
4. Fail fast on duplicate keys, population mismatch, missing model features, or score-length mismatch.
5. Gini comparison must remain paired because baseline and candidate score the same observations.
6. Preserve row-level diagnostics as optional; aggregated outputs must be sufficient for executive reporting.
7. Do not silently change score scale. The default 1 p.p. tolerance assumes probabilities in [0, 1].

## Engineering expectations
- Add/update tests for every behavior change.
- Prefer dataclasses and explicit types over hidden global state.
- Keep metric functions pure when possible.
- Avoid adding heavyweight dependencies without a strong reason.
- Keep public API backward-compatible within the 0.1.x implementation phase unless a bug requires correction.
- Use deterministic random seeds in bootstrap tests/examples.

## Before considering a task complete
Run:

```bash
PYTHONPATH=src pytest -q
PYTHONPATH=src python examples/toy_example.py
python -m compileall -q src tests examples project_template
```

If editable installation is needed in a network-restricted environment, use the existing environment's build tooling with `pip install -e . --no-build-isolation`.
