import numpy as np
import pandas as pd

from model_source_impact import (
    AcceptanceThresholds,
    ExperimentConfig,
    ExperimentRunner,
    FeatureSpec,
    ModelConfig,
    SourceMigrationConfig,
    SourceSide,
)


def _population_builder(model, reference_date, include_target):
    frame = pd.DataFrame({"id": np.arange(1000)})
    frame["target"] = (frame["id"] % 7 == 0).astype(int)
    return frame if include_target else frame.drop(columns="target")


def _feature_builder(population, model, migrations, side, reference_date):
    frame = population.copy()
    frame["x1"] = frame["id"] / 1000
    frame["x2"] = (frame["id"] % 10) / 10
    if side == SourceSide.CANDIDATE:
        frame.loc[frame["id"] == 5, "x1"] += 1e-10
    return frame


def _scorer(frame, model):
    z = -1 + frame["x1"].to_numpy() + frame["x2"].to_numpy()
    return 1 / (1 + np.exp(-z))


def _runner():
    models = {
        "m": ModelConfig(
            name="m",
            id_cols=("id",),
            target_col="target",
            feature_names=("x1", "x2"),
            risk_group_cutoffs=(0.3, 0.5, 0.7),
            risk_group_labels=("G1", "G2", "G3", "G4"),
        )
    }
    migrations = {
        "x1_v2": SourceMigrationConfig(
            name="x1_v2",
            baseline_source="old.x1",
            candidate_source="new.x1",
            features=(FeatureSpec("x1", atol=1e-8),),
        )
    }
    return ExperimentRunner(
        models=models,
        migrations=migrations,
        population_builder=_population_builder,
        feature_table_builder=_feature_builder,
        scorer=_scorer,
        thresholds=AcceptanceThresholds(
            min_score_match_6dp=0.99,
            min_score_match_within_pp=0.99,
            min_risk_group_match=0.99,
            max_abs_gini_delta_points=0.25,
        ),
        keep_row_level=True,
    )


def test_recent_experiment_passes():
    result = _runner().run(
        ExperimentConfig(
            model_name="m",
            reference_date="2026-07",
            migrations=("x1_v2",),
            include_target=False,
        )
    )
    assert result.status == "PASS"
    assert result.score_metrics.match_rate_rounded > 0.99
    assert result.group_metrics.match_rate > 0.99
    assert result.performance_metrics is None
    assert result.feature_metrics.loc[0, "tolerance_match_rate"] == 1.0


def test_mature_experiment_calculates_gini():
    result = _runner().run(
        ExperimentConfig(
            model_name="m",
            reference_date="2025-06",
            migrations=("x1_v2",),
            include_target=True,
            bootstrap_iterations=30,
        )
    )
    assert result.performance_metrics is not None
    assert abs(result.performance_metrics.gini_delta_points) < 1e-6
    assert result.performance_metrics.bootstrap_valid_iterations > 0
