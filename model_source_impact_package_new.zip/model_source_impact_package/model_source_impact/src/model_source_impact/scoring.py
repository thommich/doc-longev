from __future__ import annotations

import numpy as np
import pandas as pd

from .config import ModelConfig


def default_risk_group_assigner(scores: pd.Series, model: ModelConfig) -> pd.Series:
    if model.risk_group_cutoffs is None:
        raise ValueError(
            f"Model {model.name!r} has no risk_group_cutoffs and no custom assigner was supplied"
        )

    bins = [-np.inf, *model.risk_group_cutoffs, np.inf]
    labels = model.risk_group_labels
    if labels is None:
        labels = tuple(f"G{i + 1}" for i in range(len(bins) - 1))

    grouped = pd.cut(
        scores.astype(float),
        bins=bins,
        labels=list(labels),
        right=model.right_closed_groups,
        include_lowest=True,
        ordered=True,
    )
    return pd.Series(grouped, index=scores.index, name="risk_group")
