from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd


@dataclass
class PopulationValidationResult:
    n_population: int
    n_baseline: int
    n_candidate: int
    n_matched: int
    baseline_duplicate_keys: int
    candidate_duplicate_keys: int
    baseline_only_rows: int
    candidate_only_rows: int

    @property
    def is_valid(self) -> bool:
        return (
            self.baseline_duplicate_keys == 0
            and self.candidate_duplicate_keys == 0
            and self.baseline_only_rows == 0
            and self.candidate_only_rows == 0
            and self.n_baseline == self.n_candidate == self.n_matched
        )


@dataclass
class ScoreComparisonResult:
    n: int
    match_rate_rounded: float
    match_rate_within_pp: float
    mean_diff: float
    mean_abs_diff: float
    median_abs_diff: float
    p95_abs_diff: float
    p99_abs_diff: float
    max_abs_diff: float
    pearson: float
    spearman: float


@dataclass
class GroupComparisonResult:
    n: int
    match_rate: float
    distribution: pd.DataFrame
    transition_counts: pd.DataFrame
    transition_row_pct: pd.DataFrame
    distance_distribution: pd.DataFrame | None = None


@dataclass
class PerformanceComparisonResult:
    gini_baseline_points: float
    gini_candidate_points: float
    gini_delta_points: float
    bootstrap_ci_low_points: float | None
    bootstrap_ci_high_points: float | None
    bootstrap_valid_iterations: int


@dataclass
class ExperimentResult:
    experiment_name: str
    model_name: str
    reference_date: str
    migration_names: tuple[str, ...]
    population: PopulationValidationResult
    feature_metrics: pd.DataFrame
    score_metrics: ScoreComparisonResult
    group_metrics: GroupComparisonResult | None
    performance_metrics: PerformanceComparisonResult | None
    status: str
    checks: dict[str, bool | None]
    row_level: pd.DataFrame | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
