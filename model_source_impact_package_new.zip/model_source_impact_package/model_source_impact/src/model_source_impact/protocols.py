from __future__ import annotations

from typing import Protocol, Sequence

import numpy as np
import pandas as pd

from .config import ModelConfig, SourceMigrationConfig, SourceSide


class PopulationBuilder(Protocol):
    def __call__(
        self,
        model: ModelConfig,
        reference_date: str,
        include_target: bool,
    ) -> pd.DataFrame: ...


class FeatureTableBuilder(Protocol):
    def __call__(
        self,
        population: pd.DataFrame,
        model: ModelConfig,
        migrations: Sequence[SourceMigrationConfig],
        side: SourceSide,
        reference_date: str,
    ) -> pd.DataFrame: ...


class ModelScorer(Protocol):
    def __call__(self, frame: pd.DataFrame, model: ModelConfig) -> np.ndarray | pd.Series: ...


class RiskGroupAssigner(Protocol):
    def __call__(
        self,
        scores: pd.Series,
        model: ModelConfig,
    ) -> pd.Series: ...
