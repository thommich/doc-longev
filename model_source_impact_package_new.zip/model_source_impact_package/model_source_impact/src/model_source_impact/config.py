from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Sequence


class SourceSide(str, Enum):
    BASELINE = "baseline"
    CANDIDATE = "candidate"


@dataclass(frozen=True)
class FeatureSpec:
    """Metadata for a model feature affected by a source migration."""

    name: str
    kind: str = "auto"  # auto | numeric | categorical
    atol: float = 1e-12
    rtol: float = 1e-9


@dataclass(frozen=True)
class SourceMigrationConfig:
    """Describes one legacy -> modernized source substitution."""

    name: str
    baseline_source: str
    candidate_source: str
    features: tuple[FeatureSpec, ...]
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def feature_names(self) -> tuple[str, ...]:
        return tuple(feature.name for feature in self.features)


@dataclass(frozen=True)
class ModelConfig:
    """Model-specific configuration consumed by the generic runner."""

    name: str
    teradata_flat_table: str
    id_cols: tuple[str, ...]
    feature_names: tuple[str, ...]
    target_col: str | None = None
    score_name: str = "score"
    risk_group_cutoffs: tuple[float, ...] | None = None
    risk_group_labels: tuple[str, ...] | None = None
    right_closed_groups: bool = True
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.risk_group_cutoffs is None and self.risk_group_labels is not None:
            raise ValueError("risk_group_labels requires risk_group_cutoffs")
        if self.risk_group_cutoffs is not None:
            n_groups = len(self.risk_group_cutoffs) + 1
            if self.risk_group_labels is not None and len(self.risk_group_labels) != n_groups:
                raise ValueError(
                    "risk_group_labels must contain len(risk_group_cutoffs) + 1 labels"
                )


@dataclass(frozen=True)
class AcceptanceThresholds:
    min_score_match_6dp: float = 0.999
    min_score_match_within_pp: float = 0.999
    min_risk_group_match: float = 0.999
    max_abs_gini_delta_points: float = 0.25


@dataclass(frozen=True)
class ExperimentConfig:
    model_name: str
    reference_date: str
    migrations: tuple[str, ...]
    include_target: bool = False
    experiment_name: str | None = None
    score_decimals: int = 6
    score_tolerance_pp: float = 1.0
    bootstrap_iterations: int = 500
    bootstrap_confidence: float = 0.95
    bootstrap_random_state: int = 42
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def name(self) -> str:
        return self.experiment_name or f"{self.model_name}@{self.reference_date}"
