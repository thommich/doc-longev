from __future__ import annotations

from dataclasses import asdict
from typing import Iterable

import pandas as pd

from .results import ExperimentResult


def summary_frame(results: Iterable[ExperimentResult]) -> pd.DataFrame:
    rows = []
    for result in results:
        perf = result.performance_metrics
        group = result.group_metrics
        rows.append(
            {
                "experiment": result.experiment_name,
                "model": result.model_name,
                "reference_date": result.reference_date,
                "migrations": ", ".join(result.migration_names),
                "n": result.score_metrics.n,
                "score_match_6dp": result.score_metrics.match_rate_rounded,
                "score_match_within_pp": result.score_metrics.match_rate_within_pp,
                "mean_abs_score_diff": result.score_metrics.mean_abs_diff,
                "p95_abs_score_diff": result.score_metrics.p95_abs_diff,
                "max_abs_score_diff": result.score_metrics.max_abs_diff,
                "spearman": result.score_metrics.spearman,
                "risk_group_match": None if group is None else group.match_rate,
                "gini_baseline_points": None if perf is None else perf.gini_baseline_points,
                "gini_candidate_points": None if perf is None else perf.gini_candidate_points,
                "gini_delta_points": None if perf is None else perf.gini_delta_points,
                "gini_delta_ci_low": None if perf is None else perf.bootstrap_ci_low_points,
                "gini_delta_ci_high": None if perf is None else perf.bootstrap_ci_high_points,
                "status": result.status,
            }
        )
    return pd.DataFrame(rows)


def checks_frame(result: ExperimentResult) -> pd.DataFrame:
    return pd.DataFrame(
        [{"check": key, "passed": value} for key, value in result.checks.items()]
    )
