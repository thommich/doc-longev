from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd

from .config import FeatureSpec
from .results import PopulationValidationResult


def _ensure_columns(frame: pd.DataFrame, columns: Sequence[str], frame_name: str) -> None:
    missing = [c for c in columns if c not in frame.columns]
    if missing:
        raise ValueError(f"{frame_name} is missing required columns: {missing}")


def validate_population_alignment(
    population: pd.DataFrame,
    baseline: pd.DataFrame,
    candidate: pd.DataFrame,
    id_cols: Sequence[str],
    *,
    fail_fast: bool = True,
) -> PopulationValidationResult:
    _ensure_columns(population, id_cols, "population")
    _ensure_columns(baseline, id_cols, "baseline")
    _ensure_columns(candidate, id_cols, "candidate")

    baseline_dupes = int(baseline.duplicated(list(id_cols)).sum())
    candidate_dupes = int(candidate.duplicated(list(id_cols)).sum())

    base_keys = baseline[list(id_cols)].drop_duplicates()
    cand_keys = candidate[list(id_cols)].drop_duplicates()

    merged = base_keys.merge(cand_keys, on=list(id_cols), how="outer", indicator=True)
    baseline_only = int((merged["_merge"] == "left_only").sum())
    candidate_only = int((merged["_merge"] == "right_only").sum())
    matched = int((merged["_merge"] == "both").sum())

    result = PopulationValidationResult(
        n_population=len(population),
        n_baseline=len(baseline),
        n_candidate=len(candidate),
        n_matched=matched,
        baseline_duplicate_keys=baseline_dupes,
        candidate_duplicate_keys=candidate_dupes,
        baseline_only_rows=baseline_only,
        candidate_only_rows=candidate_only,
    )

    if fail_fast and not result.is_valid:
        raise ValueError(f"Population alignment failed: {result}")

    return result


def _safe_rate(mask: pd.Series | np.ndarray) -> float:
    return float(np.mean(mask)) if len(mask) else float("nan")


def compare_feature(
    baseline: pd.Series,
    candidate: pd.Series,
    spec: FeatureSpec,
) -> dict[str, float | int | str]:
    if len(baseline) != len(candidate):
        raise ValueError("Feature series must have equal lengths")

    both_null = baseline.isna() & candidate.isna()
    baseline_only_null = baseline.isna() & candidate.notna()
    candidate_only_null = baseline.notna() & candidate.isna()
    comparable = baseline.notna() & candidate.notna()

    kind = spec.kind
    if kind == "auto":
        kind = "numeric" if (
            pd.api.types.is_numeric_dtype(baseline)
            and pd.api.types.is_numeric_dtype(candidate)
        ) else "categorical"

    result: dict[str, float | int | str] = {
        "feature": spec.name,
        "kind": kind,
        "n": len(baseline),
        "baseline_null_rate": _safe_rate(baseline.isna()),
        "candidate_null_rate": _safe_rate(candidate.isna()),
        "both_null_rate": _safe_rate(both_null),
        "baseline_null_candidate_nonnull_rate": _safe_rate(baseline_only_null),
        "baseline_nonnull_candidate_null_rate": _safe_rate(candidate_only_null),
    }

    if kind == "numeric":
        b = pd.to_numeric(baseline[comparable], errors="coerce")
        c = pd.to_numeric(candidate[comparable], errors="coerce")
        valid = b.notna() & c.notna()
        b = b[valid].astype(float)
        c = c[valid].astype(float)

        close = np.isclose(b.to_numpy(), c.to_numpy(), atol=spec.atol, rtol=spec.rtol)
        exact_nonnull = b.to_numpy() == c.to_numpy()
        abs_diff = np.abs(c.to_numpy() - b.to_numpy())

        full_exact = both_null.copy()
        full_close = both_null.copy()
        full_exact.loc[comparable] = False
        full_close.loc[comparable] = False
        comparable_idx = baseline.index[comparable]
        valid_idx = comparable_idx[valid.to_numpy()]
        full_exact.loc[valid_idx] = exact_nonnull
        full_close.loc[valid_idx] = close

        result.update(
            {
                "exact_match_rate": _safe_rate(full_exact),
                "tolerance_match_rate": _safe_rate(full_close),
                "baseline_mean": float(b.mean()) if len(b) else float("nan"),
                "candidate_mean": float(c.mean()) if len(c) else float("nan"),
                "baseline_std": float(b.std(ddof=1)) if len(b) > 1 else float("nan"),
                "candidate_std": float(c.std(ddof=1)) if len(c) > 1 else float("nan"),
                "mean_diff": float((c - b).mean()) if len(b) else float("nan"),
                "median_abs_diff": float(np.median(abs_diff)) if len(abs_diff) else float("nan"),
                "p95_abs_diff": float(np.quantile(abs_diff, 0.95)) if len(abs_diff) else float("nan"),
                "max_abs_diff": float(abs_diff.max()) if len(abs_diff) else float("nan"),
            }
        )
    elif kind == "categorical":
        exact = (baseline == candidate) | both_null
        result.update(
            {
                "exact_match_rate": _safe_rate(exact),
                "tolerance_match_rate": _safe_rate(exact),
                "baseline_mean": float("nan"),
                "candidate_mean": float("nan"),
                "baseline_std": float("nan"),
                "candidate_std": float("nan"),
                "mean_diff": float("nan"),
                "median_abs_diff": float("nan"),
                "p95_abs_diff": float("nan"),
                "max_abs_diff": float("nan"),
            }
        )
    else:
        raise ValueError(f"Unsupported feature kind: {kind}")

    return result


def compare_features(
    baseline: pd.DataFrame,
    candidate: pd.DataFrame,
    specs: Sequence[FeatureSpec],
) -> pd.DataFrame:
    rows = []
    for spec in specs:
        _ensure_columns(baseline, [spec.name], "baseline")
        _ensure_columns(candidate, [spec.name], "candidate")
        rows.append(compare_feature(baseline[spec.name], candidate[spec.name], spec))
    return pd.DataFrame(rows)
