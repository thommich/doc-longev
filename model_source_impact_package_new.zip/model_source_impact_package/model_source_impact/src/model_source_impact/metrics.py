from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score

from .results import GroupComparisonResult, PerformanceComparisonResult, ScoreComparisonResult


def compare_scores(
    baseline_scores: pd.Series,
    candidate_scores: pd.Series,
    *,
    decimals: int = 6,
    tolerance_pp: float = 1.0,
) -> ScoreComparisonResult:
    b = pd.Series(baseline_scores, dtype=float).reset_index(drop=True)
    c = pd.Series(candidate_scores, dtype=float).reset_index(drop=True)
    if len(b) != len(c):
        raise ValueError("Score vectors must have the same length")
    if b.isna().any() or c.isna().any():
        raise ValueError("Score comparison does not accept missing scores")

    diff = c.to_numpy() - b.to_numpy()
    abs_diff = np.abs(diff)
    rounded_match = np.round(b.to_numpy(), decimals) == np.round(c.to_numpy(), decimals)
    probability_tolerance = tolerance_pp / 100.0
    within_pp = abs_diff <= probability_tolerance

    pearson = float(np.corrcoef(b, c)[0, 1]) if len(b) > 1 else float("nan")
    spear = spearmanr(b, c).statistic if len(b) > 1 else float("nan")

    return ScoreComparisonResult(
        n=len(b),
        match_rate_rounded=float(rounded_match.mean()),
        match_rate_within_pp=float(within_pp.mean()),
        mean_diff=float(diff.mean()) if len(diff) else float("nan"),
        mean_abs_diff=float(abs_diff.mean()) if len(abs_diff) else float("nan"),
        median_abs_diff=float(np.median(abs_diff)) if len(abs_diff) else float("nan"),
        p95_abs_diff=float(np.quantile(abs_diff, 0.95)) if len(abs_diff) else float("nan"),
        p99_abs_diff=float(np.quantile(abs_diff, 0.99)) if len(abs_diff) else float("nan"),
        max_abs_diff=float(abs_diff.max()) if len(abs_diff) else float("nan"),
        pearson=pearson,
        spearman=float(spear),
    )


def compare_groups(
    baseline_groups: pd.Series,
    candidate_groups: pd.Series,
    *,
    ordered_labels: list[str] | tuple[str, ...] | None = None,
) -> GroupComparisonResult:
    b = pd.Series(baseline_groups).reset_index(drop=True)
    c = pd.Series(candidate_groups).reset_index(drop=True)
    if len(b) != len(c):
        raise ValueError("Risk-group vectors must have the same length")

    match = (b == c) | (b.isna() & c.isna())
    labels = list(ordered_labels) if ordered_labels is not None else sorted(
        set(b.dropna().astype(str)).union(c.dropna().astype(str))
    )

    b_cat = pd.Categorical(b.astype("string"), categories=labels, ordered=True)
    c_cat = pd.Categorical(c.astype("string"), categories=labels, ordered=True)

    counts = pd.crosstab(b_cat, c_cat, dropna=False)
    counts.index.name = "baseline_group"
    counts.columns.name = "candidate_group"
    row_pct = counts.div(counts.sum(axis=1).replace(0, np.nan), axis=0)

    distribution = pd.DataFrame(
        {
            "baseline_count": pd.Series(b_cat).value_counts(sort=False),
            "candidate_count": pd.Series(c_cat).value_counts(sort=False),
        }
    ).fillna(0)
    distribution["baseline_pct"] = distribution["baseline_count"] / max(len(b), 1)
    distribution["candidate_pct"] = distribution["candidate_count"] / max(len(c), 1)
    distribution["delta_pp"] = 100.0 * (
        distribution["candidate_pct"] - distribution["baseline_pct"]
    )
    distribution.index = labels
    distribution.index.name = "risk_group"

    distance_distribution = None
    if ordered_labels is not None:
        rank = {label: i for i, label in enumerate(labels)}
        distances = []
        for old, new in zip(b.astype("string"), c.astype("string")):
            if pd.isna(old) or pd.isna(new) or old not in rank or new not in rank:
                distances.append(np.nan)
            else:
                distances.append(abs(rank[str(new)] - rank[str(old)]))
        s = pd.Series(distances, name="group_distance")
        valid = s.dropna().astype(int)
        if len(valid):
            distance_distribution = (
                valid.value_counts().sort_index().rename("count").to_frame()
            )
            distance_distribution["pct"] = distance_distribution["count"] / len(valid)

    return GroupComparisonResult(
        n=len(b),
        match_rate=float(match.mean()) if len(match) else float("nan"),
        distribution=distribution,
        transition_counts=counts,
        transition_row_pct=row_pct,
        distance_distribution=distance_distribution,
    )


def gini_points(y_true: pd.Series | np.ndarray, scores: pd.Series | np.ndarray) -> float:
    auc = roc_auc_score(np.asarray(y_true), np.asarray(scores))
    return float((2.0 * auc - 1.0) * 100.0)


def compare_performance(
    y_true: pd.Series | np.ndarray,
    baseline_scores: pd.Series | np.ndarray,
    candidate_scores: pd.Series | np.ndarray,
    *,
    bootstrap_iterations: int = 500,
    confidence: float = 0.95,
    random_state: int = 42,
) -> PerformanceComparisonResult:
    y = np.asarray(y_true)
    b = np.asarray(baseline_scores, dtype=float)
    c = np.asarray(candidate_scores, dtype=float)
    if not (len(y) == len(b) == len(c)):
        raise ValueError("Target and score vectors must have equal lengths")

    g_b = gini_points(y, b)
    g_c = gini_points(y, c)
    observed_delta = g_c - g_b

    ci_low = ci_high = None
    valid_iterations = 0

    if bootstrap_iterations > 0:
        rng = np.random.default_rng(random_state)
        deltas: list[float] = []
        n = len(y)
        for _ in range(bootstrap_iterations):
            idx = rng.integers(0, n, size=n)
            y_i = y[idx]
            if np.unique(y_i).size < 2:
                continue
            deltas.append(gini_points(y_i, c[idx]) - gini_points(y_i, b[idx]))

        valid_iterations = len(deltas)
        if deltas:
            alpha = 1.0 - confidence
            ci_low, ci_high = np.quantile(deltas, [alpha / 2.0, 1.0 - alpha / 2.0])
            ci_low, ci_high = float(ci_low), float(ci_high)

    return PerformanceComparisonResult(
        gini_baseline_points=g_b,
        gini_candidate_points=g_c,
        gini_delta_points=observed_delta,
        bootstrap_ci_low_points=ci_low,
        bootstrap_ci_high_points=ci_high,
        bootstrap_valid_iterations=valid_iterations,
    )
