from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd

from .config import (
    AcceptanceThresholds,
    ExperimentConfig,
    FeatureSpec,
    ModelConfig,
    SourceMigrationConfig,
    SourceSide,
)
from .metrics import compare_groups, compare_performance, compare_scores
from .protocols import FeatureTableBuilder, ModelScorer, PopulationBuilder, RiskGroupAssigner
from .reporting import summary_frame
from .results import ExperimentResult
from .scoring import default_risk_group_assigner
from .validation import compare_features, validate_population_alignment


@dataclass
class ExperimentRunner:
    models: Mapping[str, ModelConfig]
    migrations: Mapping[str, SourceMigrationConfig]
    population_builder: PopulationBuilder
    feature_table_builder: FeatureTableBuilder
    scorer: ModelScorer
    thresholds: AcceptanceThresholds = AcceptanceThresholds()
    risk_group_assigner: RiskGroupAssigner = default_risk_group_assigner
    keep_row_level: bool = False
    fail_fast_population_validation: bool = True

    def _resolve(self, config: ExperimentConfig):
        try:
            model = self.models[config.model_name]
        except KeyError as exc:
            raise KeyError(f"Unknown model {config.model_name!r}") from exc

        selected = []
        for migration_name in config.migrations:
            try:
                selected.append(self.migrations[migration_name])
            except KeyError as exc:
                raise KeyError(f"Unknown migration {migration_name!r}") from exc
        return model, tuple(selected)

    @staticmethod
    def _affected_specs(migrations: Sequence[SourceMigrationConfig]) -> tuple[FeatureSpec, ...]:
        specs_by_name: dict[str, FeatureSpec] = {}
        for migration in migrations:
            for spec in migration.features:
                if spec.name in specs_by_name and specs_by_name[spec.name] != spec:
                    raise ValueError(
                        f"Feature {spec.name!r} appears in multiple migrations with conflicting specs"
                    )
                specs_by_name[spec.name] = spec
        return tuple(specs_by_name.values())

    @staticmethod
    def _align_frames(
        baseline: pd.DataFrame,
        candidate: pd.DataFrame,
        id_cols: Sequence[str],
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        key_cols = list(id_cols)
        b = baseline.sort_values(key_cols).reset_index(drop=True)
        c = candidate.sort_values(key_cols).reset_index(drop=True)
        if not b[key_cols].equals(c[key_cols]):
            raise ValueError("Frames could not be aligned on id_cols")
        return b, c

    def run(self, config: ExperimentConfig) -> ExperimentResult:
        model, selected_migrations = self._resolve(config)

        population = self.population_builder(
            model,
            config.reference_date,
            config.include_target,
        ).copy()

        baseline = self.feature_table_builder(
            population.copy(),
            model,
            selected_migrations,
            SourceSide.BASELINE,
            config.reference_date,
        ).copy()
        candidate = self.feature_table_builder(
            population.copy(),
            model,
            selected_migrations,
            SourceSide.CANDIDATE,
            config.reference_date,
        ).copy()

        population_validation = validate_population_alignment(
            population,
            baseline,
            candidate,
            model.id_cols,
            fail_fast=self.fail_fast_population_validation,
        )
        baseline, candidate = self._align_frames(baseline, candidate, model.id_cols)

        affected_specs = self._affected_specs(selected_migrations)
        feature_metrics = compare_features(baseline, candidate, affected_specs)

        missing_model_features_b = [f for f in model.feature_names if f not in baseline.columns]
        missing_model_features_c = [f for f in model.feature_names if f not in candidate.columns]
        if missing_model_features_b or missing_model_features_c:
            raise ValueError(
                "Missing scoring features. "
                f"baseline={missing_model_features_b}, candidate={missing_model_features_c}"
            )

        baseline_scores = pd.Series(self.scorer(baseline, model), index=baseline.index, dtype=float)
        candidate_scores = pd.Series(self.scorer(candidate, model), index=candidate.index, dtype=float)
        if len(baseline_scores) != len(baseline) or len(candidate_scores) != len(candidate):
            raise ValueError("Scorer must return exactly one score per input row")

        score_metrics = compare_scores(
            baseline_scores,
            candidate_scores,
            decimals=config.score_decimals,
            tolerance_pp=config.score_tolerance_pp,
        )

        group_metrics = None
        baseline_groups = candidate_groups = None
        if model.risk_group_cutoffs is not None or self.risk_group_assigner is not None:
            try:
                baseline_groups = self.risk_group_assigner(baseline_scores, model)
                candidate_groups = self.risk_group_assigner(candidate_scores, model)
                ordered_labels = model.risk_group_labels
                group_metrics = compare_groups(
                    baseline_groups,
                    candidate_groups,
                    ordered_labels=ordered_labels,
                )
            except ValueError:
                if model.risk_group_cutoffs is not None:
                    raise

        performance_metrics = None
        if config.include_target:
            if model.target_col is None:
                raise ValueError("include_target=True but model.target_col is not configured")
            if model.target_col in baseline.columns:
                y = baseline[model.target_col]
            elif model.target_col in population.columns:
                target_frame = population[list(model.id_cols) + [model.target_col]].sort_values(
                    list(model.id_cols)
                ).reset_index(drop=True)
                y = target_frame[model.target_col]
            else:
                raise ValueError(f"Target column {model.target_col!r} is unavailable")

            performance_metrics = compare_performance(
                y,
                baseline_scores,
                candidate_scores,
                bootstrap_iterations=config.bootstrap_iterations,
                confidence=config.bootstrap_confidence,
                random_state=config.bootstrap_random_state,
            )

        checks: dict[str, bool | None] = {
            "population_alignment": population_validation.is_valid,
            "score_match_rounded": (
                score_metrics.match_rate_rounded >= self.thresholds.min_score_match_6dp
            ),
            "score_match_within_pp": (
                score_metrics.match_rate_within_pp >= self.thresholds.min_score_match_within_pp
            ),
            "risk_group_match": None,
            "gini_delta": None,
        }
        if group_metrics is not None:
            checks["risk_group_match"] = (
                group_metrics.match_rate >= self.thresholds.min_risk_group_match
            )
        if performance_metrics is not None:
            checks["gini_delta"] = (
                abs(performance_metrics.gini_delta_points)
                <= self.thresholds.max_abs_gini_delta_points
            )

        applicable = [value for value in checks.values() if value is not None]
        status = "PASS" if applicable and all(applicable) else "INVESTIGATE"

        row_level = None
        if self.keep_row_level:
            row_level = baseline[list(model.id_cols)].copy()
            row_level["baseline_score"] = baseline_scores
            row_level["candidate_score"] = candidate_scores
            row_level["score_diff"] = candidate_scores - baseline_scores
            row_level["abs_score_diff"] = np.abs(row_level["score_diff"])
            if baseline_groups is not None and candidate_groups is not None:
                row_level["baseline_group"] = baseline_groups.astype("string")
                row_level["candidate_group"] = candidate_groups.astype("string")
                row_level["group_match"] = row_level["baseline_group"] == row_level["candidate_group"]
            if config.include_target and model.target_col is not None:
                row_level[model.target_col] = np.asarray(y)

        return ExperimentResult(
            experiment_name=config.name,
            model_name=model.name,
            reference_date=config.reference_date,
            migration_names=tuple(m.name for m in selected_migrations),
            population=population_validation,
            feature_metrics=feature_metrics,
            score_metrics=score_metrics,
            group_metrics=group_metrics,
            performance_metrics=performance_metrics,
            status=status,
            checks=checks,
            row_level=row_level,
            metadata=dict(config.metadata),
        )

    def run_suite(self, configs: Iterable[ExperimentConfig]):
        results = [self.run(config) for config in configs]
        return results, summary_frame(results)
