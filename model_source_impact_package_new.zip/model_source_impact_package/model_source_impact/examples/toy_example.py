"""End-to-end example using in-memory data and a toy logistic score."""

import numpy as np
import pandas as pd

from model_source_impact import (
    AcceptanceThresholds,
    ExperimentConfig,
    ExperimentRunner,
    FeatureSpec,
    ModelConfig,
    SourceMigrationConfig,
    SourceSide,
)


MODELS = {
    "credit_model_a": ModelConfig(
        name="credit_model_a",
        id_cols=("customer_id",),
        target_col="target",
        feature_names=("income", "utilization", "age"),
        risk_group_cutoffs=(0.20, 0.40, 0.60, 0.80),
        risk_group_labels=("G1", "G2", "G3", "G4", "G5"),
    )
}

MIGRATIONS = {
    "income_v2": SourceMigrationConfig(
        name="income_v2",
        baseline_source="legacy.customer_income",
        candidate_source="modern.customer_income",
        features=(FeatureSpec("income", kind="numeric", atol=1e-8),),
    )
}


def population_builder(model, reference_date, include_target):
    rng = np.random.default_rng(7)
    n = 10_000
    frame = pd.DataFrame(
        {
            "customer_id": np.arange(n),
            "target": rng.binomial(1, 0.20, n),
        }
    )
    return frame if include_target else frame.drop(columns="target")


def feature_builder(population, model, migrations, side, reference_date):
    rng = np.random.default_rng(123)
    ids = population["customer_id"].to_numpy()
    n = len(population)
    income = 3000 + (ids % 2000) * 1.5
    if side == SourceSide.CANDIDATE:
        # Tiny source-system numerical noise, intentionally harmless.
        income = income + np.where(ids % 997 == 0, 1e-9, 0.0)

    out = population.copy()
    out["income"] = income
    out["utilization"] = (ids % 100) / 100
    out["age"] = 20 + (ids % 55)
    return out


def scorer(frame, model):
    z = (
        -2.2
        - 0.00008 * frame["income"].to_numpy()
        + 2.1 * frame["utilization"].to_numpy()
        + 0.012 * frame["age"].to_numpy()
    )
    return 1.0 / (1.0 + np.exp(-z))


runner = ExperimentRunner(
    models=MODELS,
    migrations=MIGRATIONS,
    population_builder=population_builder,
    feature_table_builder=feature_builder,
    scorer=scorer,
    thresholds=AcceptanceThresholds(
        min_score_match_6dp=0.999,
        min_score_match_within_pp=1.0,
        min_risk_group_match=0.999,
        max_abs_gini_delta_points=0.25,
    ),
    keep_row_level=True,
)

experiments = [
    ExperimentConfig(
        model_name="credit_model_a",
        reference_date="2026-07",
        migrations=("income_v2",),
        include_target=False,
        experiment_name="credit_model_a_recent",
    ),
    ExperimentConfig(
        model_name="credit_model_a",
        reference_date="2025-06",
        migrations=("income_v2",),
        include_target=True,
        experiment_name="credit_model_a_matured",
        bootstrap_iterations=200,
    ),
]

results, summary = runner.run_suite(experiments)
print(summary.to_string(index=False))
print("\nFeature reconciliation:\n", results[0].feature_metrics.to_string(index=False))
print("\nGroup transition matrix:\n", results[0].group_metrics.transition_counts)
