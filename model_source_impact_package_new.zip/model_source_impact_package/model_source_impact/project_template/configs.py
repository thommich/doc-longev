"""Replace placeholders with the 9 production models and 5 table migrations."""

from model_source_impact import (
    AcceptanceThresholds,
    ExperimentConfig,
    FeatureSpec,
    ModelConfig,
    SourceMigrationConfig,
)


MODELS = {
    "BORDO": ModelConfig(
        name="BORDO",
        teradata_flat_table="MEBM_V.VDC6",
        id_cols=("pk_riznumdoc_xx",),
        target_col="target",
        feature_names=(
            # Canonical feature names expected by the production model.
        ),
        risk_group_cutoffs=(
            # Existing production cut points, in score scale.
        ),
        risk_group_labels=(
            # e.g. "GH1", "GH2", ...
        ),
        metadata={
            "artifact_uri": "TODO",
            "owner": "TODO",
        },
    ),
}


MIGRATIONS = {
    "TABLE_01_V2": SourceMigrationConfig(
        name="TABLE_01_V2",
        baseline_source="TODO.legacy_table_01",
        candidate_source="TODO.modern_table_01",
        features=(
            # Add every canonical model feature sourced from this table.
            # FeatureSpec("feature_a", kind="numeric", atol=1e-12, rtol=1e-9),
        ),
    ),
}


THRESHOLDS = AcceptanceThresholds(
    min_score_match_6dp=0.999,
    min_score_match_within_pp=0.999,
    min_risk_group_match=0.999,
    max_abs_gini_delta_points=0.25,
)


EXPERIMENTS = [
    ExperimentConfig(
        model_name="MODEL_01",
        reference_date="YYYY-MM",  # recent reference
        migrations=("TABLE_01_V2",),
        include_target=False,
        experiment_name="MODEL_01_recent",
    ),
    ExperimentConfig(
        model_name="MODEL_01",
        reference_date="YYYY-MM",  # matured historical reference
        migrations=("TABLE_01_V2",),
        include_target=True,
        experiment_name="MODEL_01_matured",
        bootstrap_iterations=500,
    ),
]
