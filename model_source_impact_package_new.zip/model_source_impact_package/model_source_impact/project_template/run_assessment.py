from model_source_impact import ExperimentRunner

from adapters import feature_table_builder, population_builder, scorer
from configs import EXPERIMENTS, MIGRATIONS, MODELS, THRESHOLDS


runner = ExperimentRunner(
    models=MODELS,
    migrations=MIGRATIONS,
    population_builder=population_builder,
    feature_table_builder=feature_table_builder,
    scorer=scorer,
    thresholds=THRESHOLDS,
    keep_row_level=True,
)

results, summary = runner.run_suite(EXPERIMENTS)
print(summary.to_string(index=False))

# Example investigation hooks:
# result = results[0]
# print(result.feature_metrics)
# print(result.group_metrics.transition_counts)
# print(result.row_level.nlargest(100, "abs_score_diff"))
