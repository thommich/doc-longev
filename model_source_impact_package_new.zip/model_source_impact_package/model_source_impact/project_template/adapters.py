"""Infrastructure-specific adapters.

This file is intentionally a scaffold. Replace the TODOs with your existing
Athena/Spark/SageMaker utilities rather than putting infrastructure code inside
model_source_impact itself.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from model_source_impact import ModelConfig, SourceMigrationConfig, SourceSide


def population_builder(
    model: ModelConfig,
    reference_date: str,
    include_target: bool,
) -> pd.DataFrame:
    """Return exactly one immutable experiment population.

    Recommended contract:
    - one row per model key (`model.id_cols`);
    - target included only when requested / available;
    - no feature-source join in this function;
    - deterministic for a given model/reference date.
    """

    if include_target:
        query_pop = f"""
            SELECT
                {",".join([model.id_cols])}
                {", target" if include_target else ""}
            FROM {model.teradata_flat_table}
            LEFT JOIN MEBM_V.FOUCAULT
            WHERE PK_DATREF_XX = '{reference_date}'
        """

    else:
        query_pop = f"""
            SELECT
                {",".join([model.id_cols])}
            FROM {model.teradata_flat_table}
            WHERE PK_DATREF_XX = '{reference_date}'
        """

    df = athena.query(query_pop)
    return df


def feature_table_builder(
    population: pd.DataFrame,
    model: ModelConfig,
    migrations: tuple[SourceMigrationConfig, ...],
    side: SourceSide,
    reference_date: str,
) -> pd.DataFrame:
    """Build the full scoring table for baseline OR candidate.

    Critical rules:
    1. Start from the supplied `population`.
    2. Prefer LEFT JOIN semantics so source coverage differences become visible.
    3. Use the same transformations as production.
    4. Only source selection should differ between BASELINE and CANDIDATE.
    5. Rename physical source columns to canonical production feature names
       before returning the frame.
    6. Return all `model.feature_names` plus model keys and target if present.
    """
    raise NotImplementedError("Wire this to Athena/Spark/data-mesh feature retrieval")


def scorer(frame: pd.DataFrame, model: ModelConfig) -> np.ndarray:
    """Load the exact production artifact and return one score per row.

    Suggested implementation pattern:
    - resolve artifact/version from `model.metadata`;
    - enforce `model.feature_names` ordering;
    - apply exactly the same preprocessing/model inference path as production;
    - normalize to probability scale [0, 1] if using the default 1 p.p. metric.
    """
    raise NotImplementedError("Wire this to your production model loader/scorer")
