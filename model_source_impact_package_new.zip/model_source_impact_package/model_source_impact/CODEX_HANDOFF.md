# Codex handoff: adapt this framework to the production repository

## Objective
Integrate `model_source_impact` into the existing model-development/production repository so that 5 legacy-to-modern table migrations can be assessed consistently across 9 models.

## First task: repository reconnaissance
Before editing code, identify and document:
1. The canonical population-building entry point for each of the 9 models.
2. The existing feature retrieval/query utilities.
3. The exact production scoring path and model-artifact loader for each model family.
4. Existing risk-group/GH cut-point logic.
5. Target column definition and historical references with matured performance.
6. Existing test conventions and environment/dependency management.

Do not reimplement any production transformation that can be called directly.

## Second task: build registries
Populate `ModelConfig` for all 9 models and `SourceMigrationConfig` for all 5 source migrations. Use canonical production feature names.

Create an explicit model-to-migration matrix and assert that every migrated feature used by a registered model belongs to at least one configured migration.

## Third task: implement adapters
Implement:
- `population_builder`
- `feature_table_builder`
- `scorer`

The candidate feature builder must differ from baseline only in the configured source selection. Prefer fixed-population + LEFT JOIN semantics to expose source coverage gaps.

## Fourth task: integration tests
For at least one model, construct a small deterministic fixture where baseline and candidate are identical and assert:
- 100% feature tolerance match;
- 100% six-decimal score match;
- 100% within-1-p.p. score match;
- 100% GH match;
- delta Gini = 0 on the matured fixture.

Add negative tests for:
- duplicate population keys;
- missing candidate IDs;
- missing model feature;
- a source migration that changes GH assignment;
- material Gini change causing INVESTIGATE.

## Fifth task: reporting
Persist or export:
- suite-level executive summary;
- per-feature reconciliation table;
- GH distribution and transition matrix;
- top-N largest row-level score deltas;
- baseline/candidate/delta Gini with paired-bootstrap CI.

Do not add presentation-specific plotting until the numerical outputs are stable and tested.

## Constraints
- Never place credentials/secrets in config files.
- Never change production model artifacts during impact assessment.
- Keep the generic package independent from AWS SDKs unless an adapter-specific package is intentionally created.
- Record any unavoidable model-specific exception in configuration/metadata with a short rationale.
